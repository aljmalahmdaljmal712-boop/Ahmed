// ============================
// الساعة
// ============================

function updateClock() {

    const now = new Date();

    let h = String(now.getHours()).padStart(2, "0");
    let m = String(now.getMinutes()).padStart(2, "0");
    let s = String(now.getSeconds()).padStart(2, "0");

    document.getElementById("clock").textContent =
        h + ":" + m + ":" + s;
}

setInterval(updateClock, 1000);

updateClock();


// ============================
// فتح الأقسام
// ============================

function openSection(id) {

    document.getElementById("home").style.display = "none";

    document.querySelectorAll(".section").forEach(function(section) {

        section.classList.remove("active");

    });

    document.getElementById(id).classList.add("active");
}


// ============================
// الرجوع للرئيسية
// ============================

function goHome() {

    document.querySelectorAll(".section").forEach(function(section) {

        section.classList.remove("active");

    });

    document.getElementById("home").style.display = "grid";
}


// ============================
// إضافة درس
// ============================

function addLesson() {

    const input = document.getElementById("lessonInput");

    if (input.value.trim() === "") {
        return;
    }

    const lesson = document.createElement("div");

    lesson.className = "item";

    lesson.textContent = "📘 " + input.value;

    document.getElementById("lessonList").appendChild(lesson);

    input.value = "";
}


// ============================
// الصلاة
// ============================

function donePrayer(button) {

    button.textContent = "✅ تم";

    button.style.background = "#20a968";

    button.style.color = "white";
}


// ============================
// القرآن
// ============================

function saveQuran() {

    const pages =
        document.getElementById("quranPages").value;

    if (pages === "") {
        return;
    }

    document.getElementById("quranResult").textContent =
        "📖 قرأت اليوم " + pages + " صفحة من القرآن.";
}


// ============================
// إضافة مهمة
// ============================

function addTask() {

    const input =
        document.getElementById("taskInput");

    if (input.value.trim() === "") {
        return;
    }

    const task =
        document.createElement("div");

    task.className = "item";

    task.innerHTML = `
        <label>
            <input type="checkbox">
            ${input.value}
        </label>
    `;

    document.getElementById("taskList")
        .appendChild(task);

    input.value = "";
}


// ============================
// مؤقت المذاكرة
// ============================

let time = 25 * 60;

let timerInterval = null;


function updateTimer() {

    let minutes = Math.floor(time / 60);

    let seconds = time % 60;

    document.getElementById("timer").textContent =
        String(minutes).padStart(2, "0")
        + ":"
        + String(seconds).padStart(2, "0");
}


function startTimer() {

    if (timerInterval !== null) {
        return;
    }

    timerInterval = setInterval(function() {

        if (time > 0) {

            time--;

            updateTimer();

        } else {

            clearInterval(timerInterval);

            timerInterval = null;

            alert("🎉 انتهى وقت المذاكرة!");

        }

    }, 1000);
}


function pauseTimer() {

    clearInterval(timerInterval);

    timerInterval = null;
}


function resetTimer() {

    pauseTimer();

    time = 25 * 60;

    updateTimer();
}


updateTimer();